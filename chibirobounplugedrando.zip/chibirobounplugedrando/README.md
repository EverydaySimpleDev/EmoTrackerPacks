# Chibi Robo Unpluged: EmoTracker

EmoTracker pack for Chibi Robo Unpluged

Super Metroid Redesign Randomizer: https://github.com/EverydaySimpleDev/Chibi-Robo-Randomizer

Get EmoTracker here: https://emotracker.net/

## Installation

Get it on emotracker! No crazy install!

But if you want to do the crazy install:

Download the zip file, and extract it into:
C:\Users\[Your Username]\Documents\EmoTracker\packs

Open EmoTracker. In the top right, select the gear. In the menu, this tracker will be listed under Other.
